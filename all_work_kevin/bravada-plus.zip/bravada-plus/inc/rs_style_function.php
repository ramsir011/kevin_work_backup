<?php



function rs_custom_style() {
  wp_enqueue_style( 'rs_styles', get_template_directory_uri() . '/rs_assets/css/rs.css', array(), '9.1', 'all');
  
  wp_enqueue_script( 'script', get_template_directory_uri() . '/js/script.js', array ( 'jquery' ), 1.1, true);
  
}
add_action( 'wp_enqueue_scripts', 'rs_custom_style' );