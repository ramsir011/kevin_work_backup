<?php



/**
 * Functions file - Calls all other required files
 *
 * PLEASE DO NOT EDIT THEME FILES DIRECTLY
 * unless you are prepared to lose all changes on the next update
 *
 * @package Bravada
 */

// theme identification and options management - do NOT edit unless you know what you are doing
define ( "_CRYOUT_THEME_NAME", "bravada-plus" );
define ( "_CRYOUT_THEME_VERSION", "1.0.6.1" );

// prefixes for theme options and functions
define ( '_CRYOUT_THEME_SLUG', 'bravada' );
define ( '_CRYOUT_THEME_PREFIX', 'theme' );

require_once( get_template_directory() . "/cryout/framework.php" );		// Framework
require_once( get_template_directory() . "/admin/defaults.php" );		// Options Defaults
require_once( get_template_directory() . "/plus/plus.php" );			// Plus
require_once( get_template_directory() . "/admin/main.php" );			// Admin side

// Frontend side
require_once( get_template_directory() . "/includes/setup.php" );       	// Setup and init theme
require_once( get_template_directory() . "/includes/styles.php" );      	// Register and enqeue css styles and scripts
require_once( get_template_directory() . "/includes/loop.php" );        	// Loop functions
require_once( get_template_directory() . "/includes/comments.php" );    	// Comment functions
require_once( get_template_directory() . "/includes/core.php" );        	// Core functions
require_once( get_template_directory() . "/includes/hooks.php" );       	// Hooks
require_once( get_template_directory() . "/includes/meta.php" );        	// Custom Post Metas
require_once( get_template_directory() . "/includes/landing-page.php" );	// Landing Page outputs
if ( class_exists( 'WooCommerce' ) ) {
	require_once( get_template_directory() . "/includes/woocommerce.php" );	// WooCommerce overrides
}


/**
 * Define the metabox and field configurations.
 * rs added theme-functions.php
 * 
 * 
 */
 // require get_template_directory() . '/inc/theme-options.php';
  
    
 add_action( 'cmb2_admin_init', 'cmb2_rs_metaboxes' );

function cmb2_rs_metaboxes() {
  

	/**
	 * Initiate the metabox
	 */
    $rs_cmb_repeat = new_cmb2_box( array(
		'id'            =>  'floor_plan_gallery',
		'title'         =>  'Gallery',
		'object_types' => [ 'page' ], // post type
			'show_on'      => [ 'key' => 'page-template', 'value' => 'page-filter.php' ],
		'context'       => 'normal',
		'priority'      => 'low',
		'show_names'    => true,
	) );
	$rs_cmb_repeat->add_field( [
    'name'    =>  'Heading',
            'id'      =>  'price',
            'description' => 'Starting title',
            'type'    => 'text',
] );
	$rs_cmb_repeat->add_field( [
    'name'    =>  'Apply now',
            'id'      =>  'link',
            'description' => ' Apply now page Link',
            'type'    => 'text_url',
] );
   $rs_group_repeat = $rs_cmb_repeat->add_field( array(
            'id'          => 'floor_plan_sections',
            'type'        => 'group',
            'options'     => [
                'group_title'   =>  'Gallery',
                'add_button'    =>  'Add another Gallery',
                'remove_button' =>  'Remove Gallery' ,
                'sortable'      => true, // beta
			],
        ) );
	   
		$rs_cmb_repeat->add_group_field(  $rs_group_repeat, [
            'name'    => 'Floor Plain Image',
            'id'      => 'floor_image',
			 'description' => 'Upload Plain image',
            'type'    => 'file',
			'attributes' => [ 'required' =>'required']
        ] );
        
		$rs_cmb_repeat->add_group_field(  $rs_group_repeat, [
            'name'    => 'Floor detail Image',
            'id'      => 'floor_image_image',
			 'description' => 'Upload detail image of floor plan',
            'type'    => 'file',
			'attributes' => [ 'required' =>'required']
        ] );
         $rs_cmb_repeat->add_group_field(  $rs_group_repeat, array(
            'name'    =>  'Css Class Name',
            'id'      =>  'title_1',
			'description' => 'Put Css class. Just put (onebed, if it is one bedroom, twobed if it is two bedroom, threebed, fourbed, fivebed, sixbed, sevenbed, eightbed) according to number of beds ',
            'type'    => 'text',
			 'attributes' => [ 'required' =>'required']
            
        ) );
    
        $rs_cmb_repeat->add_group_field(  $rs_group_repeat, array(
            'name'    =>  'Image title',
            'id'      =>  'title_2',
            'description' => 'Put the image title.',
            'type'    => 'text',
            
        ) );
        $rs_cmb_repeat->add_group_field(  $rs_group_repeat, array(
            'name'    =>  'Image information(sq.ft)',
            'id'      =>  'title_3',
            'description' => 'Put the image information.',
            'type'    => 'text',
            
        ) );
    
        $rs_cmb_repeat->add_group_field(  $rs_group_repeat, array(
            'name'    =>  'Data Caption',
            'id'      =>  'data_caption',
            'description' => 'Put the data caption. (It appears when we click image ) ',
            'type'    => 'text',
            
        ) );
          $rs_cmb_repeat->add_group_field(  $rs_group_repeat, array(
            'name'    =>  'Starting price',
            'id'      =>  'starting_price',
            'description' => 'Put starting price ',
            'type'    => 'text',
            
        ) );
      
          $rs_cmb_repeat->add_group_field(  $rs_group_repeat, array(
            'name'    =>  'Left Icon title',
            'id'      =>  'left_icon_title',
			'description' => 'Put the icon title.',
            'type'    => 'text',
			'attributes' => [ 'required' =>'required']
            
        ) );
          $rs_cmb_repeat->add_group_field(  $rs_group_repeat, array(
            'name'    =>  'Right Icon title',
            'id'      =>  'right_icon_title',
			'description' => 'Put the icon title.',
            'type'    => 'text',
			'attributes' => [ 'required' =>'required']
            
        ) );
           $rs_cmb_repeat->add_group_field(  $rs_group_repeat, array(
            'name'    =>  'Availability',
            'id'      =>  'call_title',
            'description' => 'Call for Availability  ',
            'type'    => 'text',
            
        ) );

}
