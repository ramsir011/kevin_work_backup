$('[data-fancybox="images"]').fancybox({
    baseClass: 'myFancyBox',
    thumbs: {
        autoStart: true,
        axis: 'x'
    }
})

jQuery(document).ready(function($) {
    $('.rs__list').click(function() {

        const value = $(this).attr('data-filter');

        if (value == 'all') {
            $('.fancy__image__content').show('1000')
        } else {
            $('.fancy__image__content').not('.' + value).hide('1000');
            $('.fancy__image__content').filter('.' + value).show('1000');
        }
    })

    $('.rs__list').click(function() {
        $(this).addClass('active').siblings().removeClass('active')
    })

})