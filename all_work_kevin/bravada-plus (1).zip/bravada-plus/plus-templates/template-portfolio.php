<?php
/*
 * Template Name: Portfolio
 *
 * @package Cryout Plus
 */
 
// retrieve specific page metas
for ($i=1;$i<=5;$i++) { // 0 is usually an image
	$cryout_page_meta[$i] = get_post_meta( get_the_ID(), '_cryout_meta_templatefield_'.$i, true );
}
// filter status needs a default when unset
if ( isset( $cryout_page_meta[1] ) && ( '' === $cryout_page_meta[1] ) ) $cryout_page_meta[1] = 1;

get_header(); ?>

	<div id="container" class="<?php call_user_func( _CRYOUT_THEME_SLUG . '_get_layout_class' ); ?>">

		<main id="main" class="main">
			<?php cryout_before_content_hook(); ?>

			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="schema-image">
						<?php cryout_featured_hook(); ?>
					</div>
					<div class="article-inner">
						<header>
							<?php the_title( '<h1 class="entry-title" ' . cryout_schema_microdata( 'entry-title', 0 ) . '>', '</h1>' ); ?>
							<span class="entry-meta" >
								<?php edit_post_link( __( 'Edit', 'cryout' ), '<span class="edit-link"><i class="icon-edit"></i> ', '</span>' ); ?>
							</span>
						</header>

						<?php cryout_singular_before_inner_hook();  ?>

						<div class="entry-content" <?php cryout_schema_microdata( 'text' ); ?>>
							<?php the_content(); ?>
							<?php // wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'cryout' ), 'after' => '</div>' ) ); ?>
						</div><!-- .entry-content -->

						<?php cryout_lpportfolioplus_output(
							array(
								'post_type' => 'jetpack-portfolio',
								'tax_query' => array(),
								'posts_per_page' => ( !empty( $cryout_page_meta[2] ) ? intval( $cryout_page_meta[2] ) : -1 ),
								'order' => ( !empty( $cryout_page_meta[4] ) ? esc_html( $cryout_page_meta[4] ) : 'ASC' ),
								'orderby' => ( !empty( $cryout_page_meta[5] ) ? esc_html( $cryout_page_meta[5] ) : 'date' )
							),
							array( _CRYOUT_THEME_PREFIX . '_lpportfilter' => ( intval( $cryout_page_meta[1] ) ) ), // options override	
							false,	// titles
							( !empty( $cryout_page_meta[3] ) ? intval( $cryout_page_meta[3] ) : 4 )	// columns
						); var_dump($cryout_page_meta[1]); ?>

						<?php cryout_singular_after_inner_hook(); ?>
					</div><!-- .article-inner -->
				</article><!-- #post-## -->

			<?php endwhile; ?>

			<?php cryout_after_content_hook(); ?>
		</main><!-- #main -->

		<?php call_user_func( _CRYOUT_THEME_SLUG . '_get_sidebar' ); ?>

	</div><!-- #container -->

<?php get_footer();
