<?php

/**
 * Template Name:Floor plan 

 */
 
 get_header();
 

    $starting_title = get_post_meta( get_the_ID(), 'price', true );
    $apply_now_title = get_post_meta( get_the_ID(), 'link', true );
    $floor_plan = get_post_meta( get_the_ID(), 'floor_plan_sections', true );

 
?>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<script src="//code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />


<div class="fancybox__container" >
    
     
        <h1 class=' floor__title'><?php echo $starting_title?></h1>
    
     <p style="text-align: left;  color: #003b4d; margin: 0rem 0 1rem 0;">Explore a variety of 1-, 2-, and 3-bedroom cottage-style homes for rent at Hayloft Cottages. Designed for active 55+ adults in Suwanee, GA, our new construction community is perfect for someone that’s ready to enjoy the maintenance-free benefits of apartment living, without compromising the privacy and comfort of a single-family house. Each thoughtful floor plan features upscale amenities and finishes, including quartz or granite countertops, stainless steel appliances, spacious walk-in closets, private entrances, and smart home technology. Make Hayloft Cottages your first choice in the next chapter of your downsized life and enjoy a rental opportunity that doesn’t make you part with everything your previous home offered. <u><a href="https://hayloftcottages.com/contact-us/">Contact our leasing team online</a></u> or call us at <u><a href="tel:16788658914">678-865-8914</a></u> to discuss how you can rent your next house at  Hayloft Cottages in Suwanee, GA.
</p>
     
    <div class="list__container">
        
        <p class="rs__list active" data-filter='all'>All</p>
        <p class="rs__list" data-filter='onebed'>One Bedroom</p>
        <p class="rs__list" data-filter='twobed'>Two Bedroom</p>
        <p class="rs__list" data-filter='threebed'>Three Bedroom</p>
        <!--<p class="rs__list" data-filter='fourobed'>Four Bedroom</p>-->
        <!--<p class="rs__list" data-filter='fivebed'>Five Bedroom</p>-->
        <!--<p class="rs__list" data-filter='sixbed'>Six Bedroom</p>-->
        <!-- <p class="rs__list" data-filter='sevenbed'>Seven Bedroom</p>-->
        <!--<p class="rs__list" data-filter='eightbed'>Eight Bedroom</p>-->


    </div>
    <div class="fancybox__inner">
        
       <?php 
        
      foreach((array) $floor_plan as $key => $entry ){ 
     if(isset($entry['title_1']) || isset($entry['floor_image_image']) || isset($entry['floor_image']) ||isset($entry['title_1']) ||isset($entry['title_2']) ||isset($entry['title_3']) ||isset($entry['title_1'])) {
         

    ?>
         
          <div class="fancy__image__content  <?php echo $entry['title_1']?>">
               <div class="floor__img__bar .info__top">
                <p class="bottom__bar__info info__top">Call for Availability</p>
            </div>
            <a href="<?php echo $entry['floor_image_image']?>" data-fancybox="images"
                data-caption="<?php echo $entry['data_caption']?>" title='bedroom'>
                <img src="<?php echo $entry['floor_image']?>" />

            </a>

            <div class="fancy__box__information">
                <h6><?php echo $entry['title_2']?></h6>
                <p><?php echo $entry['title_3']?></p>
                 <div class="box__underline"></div>
               
            </div>
              <p class = 'starting__heading'>Starting At</p>
                 <span class= 'starting__price'><?php echo $entry['starting_price']?></span>
             <div class="icon__container">
                <div class="inner__icon__container">
                <i class="fa fa-bed fa-2x" aria-hidden="true"></i>
                <span class='icon__title'><?php echo $entry['left_icon_title']?></span>
                </div>
                <div class="inner__icon__container">
                <i class="fa fa-bath fa-2x" aria-hidden="true"></i>
                <span class='icon__title'><?php echo $entry['right_icon_title']?></span>
                </div>

            </div>
         
           
            <div class="floor__img__bar bottom__bar">
            <p class="bottom__bar__info"><?php echo $entry['call_title']?></p>
            </div>
        </div>
<?php      } } ?>


    </div>


</div>






<style>

.fancybox-thumbs {
    top: auto;
    width: auto;
    bottom: 0;
    left: 0;
    right: 0;
    height: 95px;
    padding: 10px 10px 5px 10px;
    box-sizing: border-box;
    background: rgba(0, 0, 0, 0.3);
}

.fancybox-show-thumbs .fancybox-inner {
    right: 0;
    bottom: 95px;
}
.fancybox-thumbs__list a:before{
    border:3px solid #003b4d;
}
</style>


<script>
$('[data-fancybox="images"]').fancybox({
    baseClass: 'myFancyBox',
    thumbs: {
        autoStart: true,
        axis: 'x'
    }
})

jQuery(document).ready(function($) {
    $('.rs__list').click(function() {

        const value = $(this).attr('data-filter');

        if (value == 'all') {
            $('.fancy__image__content').show('1000')
        } else {
            $('.fancy__image__content').not('.' + value).hide('1000');
            $('.fancy__image__content').filter('.' + value).show('1000');
        }
    })

    $('.rs__list').click(function() {
        $(this).addClass('active').siblings().removeClass('active')
    })

})


</script>

<?php

get_footer();