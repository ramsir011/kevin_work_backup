/*
 * Cryout Plus placeholder
 *
 * @package Cryout Plus
 *
 * This file should always remain empty and not contain any JS code.
 * It is used for various localize_script() calls.
 */